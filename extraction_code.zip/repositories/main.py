#!/usr/bin/env python
import argparse

import sys
import os
import shutil
import time
import mysql.connector
from mysql.connector import errorcode
import json
from huggingface_hub import HfApi
from huggingface_hub.repocard import RepoCard
from huggingface_hub import ModelCard

from huggingface_hub.utils import (
    HfHubHTTPError,
    GatedRepoError,
    RepositoryNotFoundError,
    EntryNotFoundError
    )
from cleantext import clean
from datetime import datetime
import dateutil.relativedelta
import pytz
import requests
import aux_hf


HOME = "https://huggingface.co"

ACCESS_TOKEN ="NA"
GLOBAL_BATCH_SIZE = 100

def parse_args(argv):
    parser = argparse.ArgumentParser(description="Manage database schema and basic info.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-s", "--scope", choices=["datasets", "models", "spaces"],
                       default="models",help="Load basic information to some.")
    
    return parser.parse_args(argv)

# AUXILIARY FUNCTIONS
def eprint(*args, **kwargs):
      """
      Auxiliar function to print errors to stderr.
      """
      print(*args, file=sys.stderr, **kwargs)


def onerror(func, path, exc_info):
      """
      Error handler for ``shutil.rmtree``. Intended for Windows usage (e.g., `Acces Denied <https://stackoverflow.com/questions/2656322/shutil-rmtree-fails-on-windows-with-access-is-denied>`_)

      If the error is due to an access error (read only file)
      it attempts to add write permission and then retries.

      If the error is for another reason it re-raises the error.

      Usage : ``shutil.rmtree(path, onerror=onerror)``
      """
      import stat
      # Is the error an access error?
      if not os.access(path, os.W_OK):
            os.chmod(path, stat.S_IWUSR)
            func(path)
      else:
            raise

def check_database_schema(cursor, database):
      """
      Auxiliar function to check if all the tables required are in the database.

      :param cursor: The MySQL connection cursor to execute operations such as SQL statements.
      :type cursor: `cursor.MySQLCursor`_
      :param database: MariaDB database name.
      :type database: str
      """
      cursor.execute("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s", [database])
      db_tables = set(list(map(lambda x: x[0], cursor.fetchall())))

      hf_tables = set(["author", "commit_parents", "commits", "dataset", "discussion", "conflicting_files_discussion", "discussion_event", "repo_file", #"modified_file",
      "files_in_commit", "model", "repository", "tag", "tags_in_repo", "space", "datasets_in_space", "models_in_space", "repo_card","model_card", "data_card", "space_card"])

      return hf_tables - db_tables

def read_config():
      """
      Function that retrieves configuration JSON from hfc.config. ( change to this function if you are not  using docker and not env varibales)

      :returns config: JSON object containing all configuration parameters.
      :rtype: JSON
      """
      if os.path.exists('hfc.config'):
            with open('hfc.config') as hfc:
                  config = json.load(hfc)
      else:
            eprint('hfc.config file not found!')
            sys.exit(1)
      return config

def validate_token(token):
      """
      Auxiliar function to validate the token placed in the env variables.

      :param str token: Hugging Face Hub `API token <https://huggingface.co/docs/hub/security-tokens>`_
      """
      url = "https://huggingface.co/api/whoami-v2"
      bearer_token = "Bearer " + token
      headers = {"Authorization": bearer_token}
      response = requests.get(url, headers=headers)
      status_code = response.status_code

      if status_code != 200:
            if status_code == 401:
                  eprint("HFH token is incorrect, please place a valid HFH token in the 'hfh_token' parameter of the env variables file.")
                  sys.exit(1)
            else:
                  eprint("Verification of HFH token. Return HTTP status code for whoami endpoint:" + str(status_code))
                  eprint("Please place a valid HFH token in the 'hfh_token' parameter of the env variables file.")
                  sys.exit(1)


# DB CONFIGURATION
def create_connection_mysql():
      """ 
      Configures a database connection to a MySQL/MariaDB database.
      Database parameters must be located in the `env variables`.

      :return: Tuple containing the MySQL connector to the database specified in the cenv variables and the database name.
      :rtype: (`connection.MySQLConnection`_, str)
      """

      conn = None

      global DB_HOST, DB_PORT, DB_USER, DB_PASS, DB_NAME  

      try :
            conn = mysql.connector.connect(user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT, database=DB_NAME)
      except KeyError as ke:
            eprint("Missing some mandatory parameters in the env variables Don't forget to specify 'user', 'pass', 'host', 'port' and 'database'.")
            sys.exit(1)
      except mysql.connector.Error as err:
            if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
                  eprint("Error in connection to the MariaDB. Something is wrong with your user name or password.")
                  sys.exit(1)
            elif err.errno == errorcode.ER_BAD_DB_ERROR:
                  print("Database specified in the env variables does not exist. Creating such database...")
                  conn = mysql.connector.connect(user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
                  conn.cursor().execute(f"CREATE DATABASE IF NOT EXISTS {DB_NAME};")
                  print("Database created!")
                  conn.cursor().execute(f"USE {DB_NAME};")
            else:
                  eprint(err)
                  sys.exit(1)
      return conn, DB_NAME


def create_schema_mysql(cursor, tables, update):
      """ 
      Creates the database schema, following this `ER diagram <https://som-research.github.io/HFCommunity/download.html#er_diagram>`_.

      :param cursor: The MySQL connection cursor to execute operations such as SQL statements.
      :type cursor: `cursor.MySQLCursor`_
      """
      
      if not update:
            print("Deleting tables..., NOT updating")
            # We have to delete the tables in order, to not break foreign key restrictions
            cursor.execute('''DROP TABLE IF EXISTS model_card''')
            cursor.execute('''DROP TABLE IF EXISTS data_card''')
            cursor.execute('''DROP TABLE IF EXISTS space_card''')

            cursor.execute('''DROP TABLE IF EXISTS repo_card''')

            cursor.execute('''DROP TABLE IF EXISTS tags_in_repo''')
            cursor.execute('''DROP TABLE IF EXISTS tag''')
            cursor.execute('''DROP TABLE IF EXISTS files_in_commit''')
            cursor.execute('''DROP TABLE IF EXISTS commit_parents''')
            cursor.execute('''DROP TABLE IF EXISTS conflicting_files_discussion''')
            cursor.execute('''DROP TABLE IF EXISTS modified_file''')
            cursor.execute('''DROP TABLE IF EXISTS repo_file''')
            cursor.execute('''DROP TABLE IF EXISTS models_in_space''') 
            cursor.execute('''DROP TABLE IF EXISTS datasets_in_space''')
            cursor.execute('''DROP TABLE IF EXISTS model''')
            cursor.execute('''DROP TABLE IF EXISTS dataset''')
            cursor.execute('''DROP TABLE IF EXISTS space''') 
            cursor.execute('''DROP TABLE IF EXISTS discussion_event''')
            cursor.execute('''DROP TABLE IF EXISTS discussion''')
            cursor.execute('''DROP TABLE IF EXISTS commits''')
            cursor.execute('''DROP TABLE IF EXISTS repository''')
            cursor.execute('''DROP TABLE IF EXISTS author''')
      
      if len(tables)!=0:
            print("Creating tables...")

      if "tag" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS tag
                  (name VARCHAR(256) PRIMARY KEY)
                  ''')
            print("Tag table created!")
            
      if "author" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS author
                  (username VARCHAR(256) PRIMARY KEY, avatar_url TEXT, is_pro INTEGER, fullname TEXT, type VARCHAR(64), source VARCHAR(256))
                  ''')
            print("Author table created!")
            
      if "repository" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS repository
                  (id VARCHAR(256) PRIMARY KEY, name TEXT, type VARCHAR(7), author VARCHAR(256), sha TEXT, last_modified DATETIME, private INTEGER, card_data LONGTEXT, gated INTEGER, likes INTEGER, disabled INTEGER, FOREIGN KEY (author) REFERENCES author(username))
                  ''')
            print("Repository table created!")
            
      if "repo_file" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS repo_file
                  (id CHAR(64) PRIMARY KEY, filename TEXT, repo_id VARCHAR(256), size BIGINT, blob_id VARCHAR(256), lfs_size BIGINT, lfs_sha VARCHAR(256), lfs_pointer_size BIGINT, FOREIGN KEY (repo_id) REFERENCES repository(id))
                  ''')
            print("Repo_file table created!")
            
      if "tags_in_repo" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS tags_in_repo
                  (tag_name VARCHAR(256), repo_id VARCHAR(256), PRIMARY KEY(tag_name, repo_id), FOREIGN KEY (tag_name) REFERENCES tag(name), FOREIGN KEY (repo_id) REFERENCES repository(id))
                  ''')
            print("Tags_in_repo table created!")
            
      if "model" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS model
                  (model_id VARCHAR(256) PRIMARY KEY, pipeline_tag TEXT, downloads INTEGER, library_name TEXT, likes INTEGER, config LONGTEXT, FOREIGN KEY (model_id) REFERENCES repository(id))
                  ''')
            print("Model table created!")
            
      if "dataset" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS dataset
                  (dataset_id VARCHAR(256) PRIMARY KEY, description LONGTEXT, citation TEXT, paperswithcode_id TEXT, downloads INTEGER, FOREIGN KEY (dataset_id) REFERENCES repository(id))
                  ''')
            print("Dataset table created!")
            
      if "space" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS space
                  (space_id VARCHAR(256) PRIMARY KEY, sdk VARCHAR(128), stage VARCHAR(32), hardware VARCHAR(32), requested_hw VARCHAR(32), sleep_time INTEGER, storage VARCHAR(32), runtime_raw TEXT, FOREIGN KEY (space_id) REFERENCES repository(id))
                  ''')
            print("Space table created!")
            
      if "models_in_space" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS models_in_space
                  (model_id VARCHAR(256), space_id VARCHAR(256), PRIMARY KEY(model_id, space_id), FOREIGN KEY (model_id) REFERENCES model(model_id), FOREIGN KEY (space_id) REFERENCES space(space_id))
                  ''')
            print("Models_in_space table created!")
            
      if "datasets_in_space" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS datasets_in_space
                  (dataset_id VARCHAR(256), space_id VARCHAR(256), PRIMARY KEY(dataset_id, space_id), FOREIGN KEY (dataset_id) REFERENCES dataset(dataset_id), FOREIGN KEY (space_id) REFERENCES space(space_id))
                  ''')
            print("Datasets_in_space table created!")
            
      if "commits" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS commits
                  (sha VARCHAR(256) PRIMARY KEY, repo_id VARCHAR(256), message LONGTEXT, author_date DATETIME, author_tz INTEGER, committer_date DATETIME, committer_tz INTEGER, in_main_branch INTEGER, insertions INTEGER, deletions INTEGER, author_name VARCHAR(256), committer_name VARCHAR(256), source VARCHAR(32), FOREIGN KEY (author_name) REFERENCES author(username), FOREIGN KEY (repo_id) REFERENCES repository(id), FOREIGN KEY (committer_name) REFERENCES author(username))
                  ''')
            print("Commits table created!")
            
      if "discussion" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS discussion
                  (num INTEGER, repo_id VARCHAR(256), author VARCHAR(256), title TEXT, status TEXT, created_at DATETIME, is_pull_request INTEGER, target_branch VARCHAR(64), merge_commit_oid VARCHAR(256), diff LONGTEXT, git_reference TEXT, PRIMARY KEY(num, repo_id), FOREIGN KEY (repo_id) REFERENCES repository(id), FOREIGN KEY (author) REFERENCES author(username), FOREIGN KEY (merge_commit_oid) REFERENCES commits(sha))
                  ''')
            print("Discussion table created!")
            
      if "conflicting_files_discussion" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS conflicting_files_discussion
                  (id INTEGER PRIMARY KEY AUTO_INCREMENT, num INTEGER, repo_id VARCHAR(256), filename TEXT, repo_file_id CHAR(64), FOREIGN KEY (repo_id) REFERENCES repository(id), FOREIGN KEY (num, repo_id) REFERENCES discussion(num, repo_id), FOREIGN KEY (repo_file_id) REFERENCES repo_file(id))
                  ''')
            print("Conflicting_files_discussion table created!")
            
      if "commit_parents" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS commit_parents
                  (commit_sha VARCHAR(256), parent_sha VARCHAR(256), PRIMARY KEY(commit_sha, parent_sha), FOREIGN KEY (commit_sha) REFERENCES commits(sha), FOREIGN KEY (parent_sha) REFERENCES commits(sha))
                  ''')
            print("Commit_parents table created!")
            
      if "modified_file" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS modified_file
                  (modified_file_id CHAR(64) PRIMARY KEY, repo_file_id CHAR(64), rfilename TEXT, old_path VARCHAR(256), new_path VARCHAR(256), change_type VARCHAR(32), diff LONGTEXT, added_lines INTEGER, deleted_lines INTEGER, nloc INTEGER, FOREIGN KEY (repo_file_id) REFERENCES repo_file(id))
                  ''')
            print("Modified_file table created!")
            
      if "files_in_commit" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS files_in_commit
                  (sha VARCHAR(256), modified_file_id CHAR(64), PRIMARY KEY(sha, modified_file_id), FOREIGN KEY (sha) REFERENCES commits(sha), FOREIGN KEY (modified_file_id) REFERENCES modified_file(modified_file_id))
                  ''')
            print("Files_in_commit table created!")

      if "discussion_event" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS discussion_event
                  (id VARCHAR(256) PRIMARY KEY, repo_id VARCHAR(256), discussion_num INTEGER,  event_type VARCHAR(64), created_at DATETIME, author VARCHAR(256), content TEXT, edited INTEGER, hidden INTEGER, new_status TEXT, summary TEXT, sha VARCHAR(256), old_title TEXT, new_title TEXT, full_data LONGTEXT, FOREIGN KEY (sha) REFERENCES commits(sha), FOREIGN KEY (author) REFERENCES author(username), FOREIGN KEY (discussion_num, repo_id) REFERENCES discussion(num, repo_id))
                  ''')
            print("Discussion_event table created!")
            
      if "repo_card" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS repo_card
                  (repo_id VARCHAR(256), card_content LONGTEXT, card_text MEDIUMTEXT,card_data MEDIUMTEXT,  PRIMARY KEY (repo_id),
                  FOREIGN KEY (repo_id) REFERENCES repository(id))
                  ''')
            print("Repo_card table created!")
            
      if "model_card" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS model_card
                  (repo_id VARCHAR(256) PRIMARY KEY, base_model VARCHAR(256), eval_results TEXT, language VARCHAR(256), licence VARCHAR(128), license_name VARCHAR(64), license_link VARCHAR(256), datasets TEXT, metrics TEXT, pipeline_tag VARCHAR(128), model_name VARCHAR(128), downloads_all_time INT, tags VARCHAR(256), model_index TEXT, FOREIGN KEY (repo_id) REFERENCES repo_card(repo_id))
                  ''')
            print("Model_card table created!")
            
      if "data_card" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS data_card
                  (repo_id VARCHAR(256) PRIMARY KEY, language VARCHAR(256), licence VARCHAR(128), annotations_creators VARCHAR(128), language_creators VARCHAR(128), source_datasets TEXT, paperswithcode_id VARCHAR(128), pretty_name VARCHAR(128), task_ids VARCHAR(256), task_categories TEXT, train_eval_index TEXT, downloads_all_time INT, FOREIGN KEY (repo_id) REFERENCES repo_card(repo_id))
                  ''')   
            print("Data_card table created!")
               
      if "space_card" in tables or "all" in tables:
            cursor.execute('''
                  CREATE TABLE IF NOT EXISTS space_card
                  (repo_id VARCHAR(256) PRIMARY KEY, title VARCHAR(256), licence VARCHAR(128), duplicated_from VARCHAR(256), models TEXT, datasets TEXT, tags VARCHAR(256), downloads_all_time INT, FOREIGN KEY (repo_id) REFERENCES repo_card(repo_id))
                  ''')
            print("Space_card table created!")
            
      if len(tables)!=0:
            print("Tables created!")
      else:
            print("Tables were already created")


# POPULATE FUNCTIONS
def populate_tags(cursor, conn, tags, repo_name, repo_type):
      """ 
      Importation of tag information. 
      It inserts tag information into the ``tag`` and ``tags_in_repo`` tables.
      
      :param cursor: The MySQL connection cursor to execute operations such as SQL statements.
      :type cursor: `cursor.MySQLCursor`_
      :param conn: The MySQL connector to the database specified in the env variables. Used to commit changes to fulfill FK restrictions.
      :type conn: `connection.MySQLConnection`_
      :param tags: A list of tag names.
      :type tags: list[str]
      :param repo_name: The full name (i.e., "owner/repo_name") of the repository.
      :type repo_name: str
      :param repo_type: The type of the repository (i.e., model, dataset or space)
      :type repo_type: str
      """
  
      for tag in tags:
            
            cursor.execute('''
            INSERT IGNORE INTO tag (name) VALUES (%s)
            ''', [tag])
            conn.commit() # Commit changes to DB to fulfill FK restriction
            cursor.execute('''
            INSERT IGNORE INTO tags_in_repo (tag_name, repo_id) VALUES (%s, %s)
            ''', (tag, repo_type + '/' + repo_name))

 
def load_model_table(conn, cursor, model_id, objt, en_commit = True): 
      
      # Cleaning of 'config' (strange characters, emojis, etc.)
      config = str(objt.get("config"))
      config = clean(objt, no_emoji=True, lower=False)
      info_model = (model_id, objt.get("pipeline_tag"), objt.get("downloads"), objt.get("library_name"), config)
      
      #print("Inserting model information into the database...")
      #print(info_model)
      
      if en_commit:
            cursor.execute(aux_hf.give_SQL_pattern("model"), info_model)
            conn.autocommit = True
            conn.commit()
      else:
            return info_model

def load_dataset_table(conn, cursor, dataset_id, objt, en_commit = True): 
      
      tags = aux_hf.too_long(str(objt.get("tags")))
      
      info_dataset = (dataset_id, objt.get("description"), objt.get("citation"), objt.get("paperswithcode_id"), objt.get("downloads"), tags)
      
      if en_commit:
            cursor.execute(aux_hf.give_SQL_pattern("dataset"), info_dataset)
            conn.autocommit = True
            conn.commit()
      else:
            return info_dataset
      
def load_spaces_table(conn, cursor, space_id, objt, en_commit = True):
      
      tags = aux_hf.too_long(str(objt.get("tags")))
      info_space = (space_id, objt.get("sdk"), objt.get("trending_score"), objt.get("used_storage"),str(objt.get("runtime_raw")), tags)
      
      if en_commit:
            cursor.execute(aux_hf.give_SQL_pattern("space"), info_space)
            conn.autocommit = True
            conn.commit()
      else:
            return info_space
      
def populate_models(cursor, conn, models_loaded_pkl, filter_m = None, part = "all", en_commit = True):
      """ 
      """
      found_filter = False
      conn.autocommit = en_commit
      lst_update_table_model = []
      updated_models_count = total_models_count = 0

      print("Retrieving full information of models...")
      print("Starting population into database...")
      
      for model in models_loaded_pkl:
            model_id = "models/" + model.get("id")
            total_models_count += 1
            print ("model_id:", model_id)
            
            if filter_m and not found_filter:
                  if filter_m == model_id:
                        found_filter = True
                        print(f"Found filter {filter_m}, processing...")
                        print(model_id)
                        continue
                  else:
                        continue
                      

            if total_models_count % 1000 == 0:
                  print(total_models_count, "models processed...")

            # Gather just those with modifications within the limit_date (e.g., last month)
            lastModified= model.get("last_modified")
            dt_utc=  aux_hf.convert_to_utc(lastModified)
            created_at = model.get("created_at")
            dt_created_utc=  aux_hf.convert_to_utc(created_at)
            
            if part == "all" or part ==  "repository":                 
                  # this is the list of some models that have a problem with the API, will be skipped
                  
                  if model.get("id") in []:#"AmirHussein/icefall-asr-mgb2-conformer_ctc-2022-27-06", "datablations/lm1-misc","tktkdrrrrrrrrrrr/CivitAI_model_info"]: # models fails 
                        continue

                  if (model.get("author") != None):
                        cursor.execute(aux_hf.give_SQL_pattern("HF_author"), (model.get("author"), "hf_owner"))
                        conn.commit()
                  
                  gated = model.get("gated")
                  if gated == False:
                        gated = 0
                  elif gated == "manual":
                        gated = 1
                  elif gated == "auto":
                        gated = 2

                  #  Ass the information to the corresponding repository
                  cursor.execute(aux_hf.give_SQL_pattern("repository"), (model_id, model.get("id"), "model", model.get("author"), model.get("sha"), dt_utc, model.get("private"), str(model.get("cardData")), gated, model.get("likes"), model.get("disabled"), dt_created_utc))
                  
                  # Commit to the DB because of the FK constraint
                  if part == "repository":
                        conn.commit()
                  
            if part == "all" or part == "model": 
                   
                  list_info_model =  load_model_table(conn, cursor, model_id, model, en_commit = en_commit)       
                  
                  if not en_commit:                        
                        lst_update_table_model.append(list_info_model)
            
            updated_models_count += 1
            if updated_models_count % GLOBAL_BATCH_SIZE == 0 and not en_commit:
                  if len(list_info_model) > 0:
                        conn.start_transaction()
                        aux_hf.insert_many(conn, aux_hf.give_SQL_pattern("model"), lst_update_table_model)
                        conn.commit()
                        lst_update_table_model.clear()         
                  
                  updated_models_count = 0
                  print(f"Committed up to the object {model_id} discussions so far...")
                           
      if en_commit == False and updated_models_count > 0:
            conn.start_transaction()
            aux_hf.insert_many(conn, aux_hf.give_SQL_pattern("model"), lst_update_table_model)
            print("Final commit after processing all objects.")
            conn.commit()
      else:
            conn.commit()  # Final commit for any remaining objects    
            # cursor.execute('''
            # INSERT INTO model (model_id, pipeline_tag, downloads, library_name, config) VALUES (%s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE pipeline_tag = values(pipeline_tag), downloads = values(downloads), library_name = values(library_name), config = values(config)
            # ''', (model_id, model.__dict__.get("pipeline_tag"), model.__dict__.get("downloads"), model.__dict__.get("library_name"), config))

            # conn.commit()
            # populate_card_repo(cursor, conn, model.id, "model", model)
            
            # populate_tags(cursor, conn, model.tags, model.modelId, "models")
            # populate_files(cursor, api, model.modelId, "model")
            # conn.commit() # Commit of files
            # populate_commits(cursor, conn, model.modelId, "models", process)
            # populate_discussions(cursor, conn, api, model.modelId, "model")


      print("Info retrieved! Gathered", total_models_count, "models")
      print(updated_models_count, "models updated!")
      print("Models population finished!")

def populate_datasets(cursor, conn, datasets_loaded_pkl, filter_m = None, part = "all", en_commit = True):
      """ 
      """
      found_filter = False
      conn.autocommit = en_commit
      lst_update_table_dtset = []
      updated_datasets_count = total_datasets_count = 0
            
      print("Retrieving full information of datasets...")      
      print("Starting population into database...")

      for dtset in datasets_loaded_pkl:
            dtset_id = "datasets/" + dtset.get("id")
            total_datasets_count += 1

            if filter_m and not found_filter: # datasets/byroneverson/shell-cmd-instruct tags too long
                  if filter_m == dtset_id:
                        found_filter = True
                        print(f"Found filter {filter_m}, processing...")
                        print(dtset_id)
                        continue
                  else:
                        print ("dataset_id: not processed", dtset_id)
                        continue
                  
            print ("dataset_id:", dtset_id)                   
            if total_datasets_count % 1000 == 0:
                  print(total_datasets_count, "datasets processed...")


            # Gather just those with modifications within the limit_date (e.g., last month)
            lastModified= dtset.get("last_modified")
            dt_utc=  aux_hf.convert_to_utc(lastModified)
            created_at = dtset.get("created_at")
            dt_created_utc=  aux_hf.convert_to_utc(created_at)
            
            if part == "all" or part ==  "repository":
             # this is the list of some models that have a problem with the API, will be skipped
                  if dtset.get("id") in []:#"AmirHussein/icefall-asr-mgb2-conformer_ctc-2022-27-06", "datablations/lm1-misc","tktkdrrrrrrrrrrr/CivitAI_model_info"]: # models fails 
                        continue

                  if (dtset.get("author") != None):
                        cursor.execute(aux_hf.give_SQL_pattern("HF_author"), (dtset.get("author"), "hf_owner"))
                        conn.commit()

                  gated = dtset.get("gated")
                  
                  if gated == False:
                        gated = 0
                  elif gated == "manual":
                        gated = 1
                  elif gated == "auto":
                        gated = 2

                  # * add securityStatus field 
                  cursor.execute(aux_hf.give_SQL_pattern("repository"), (dtset_id, dtset.get("id"), "dataset", dtset.get("author"), dtset.get("sha"), dt_utc, dtset.get("private"), str(dtset.get("cardData")), gated, dtset.get("likes"), dtset.get("disabled"), dt_created_utc))
                  
                    # Commit to the DB because of the FK constraint
                  if part == "repository":
                        conn.commit()
            if part == "all" or part == "dataset":
                  list_info_dtset = load_dataset_table(conn, cursor, dtset_id, dtset, en_commit = en_commit)
                  
                  if not en_commit:
                        lst_update_table_dtset.append(list_info_dtset)
            updated_datasets_count += 1
            
            if updated_datasets_count % GLOBAL_BATCH_SIZE == 0 and not en_commit:
                  if len(list_info_dtset) > 0:
                        conn.start_transaction()
                        aux_hf.insert_many(conn, aux_hf.give_SQL_pattern("dataset"), lst_update_table_dtset)
                        conn.commit()
                        lst_update_table_dtset.clear()
                  updated_datasets_count = 0
                  print(f"Committed up to the object {dtset_id} discussions so far...") 
      if en_commit == False and updated_datasets_count > 0:
            conn.start_transaction()
            aux_hf.insert_many(conn, aux_hf.give_SQL_pattern("dataset"), lst_update_table_dtset)
            print("Final commit after processing all objects.")
      conn.commit()  # Final commit for any remaining objects
                  
            # print("Inserted dataset")
            #             cursor.execute('''
            #             INSERT INTO dataset (dataset_id, description, citation, paperswithcode_id, downloads) VALUES (%s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE description = values(description), citation = values(citation), paperswithcode_id = values(paperswithcode_id), downloads = values(downloads)
            #             ''', (dataset_id, dataset.__dict__.get("description"), dataset.__dict__.get("citation"), dataset.__dict__.get("paperswithcode_id"), dataset.__dict__.get("downloads")))         
            #             conn.commit()

            # Commit to the DB because of the FK constraint
  

            # cursor.execute('''
            # INSERT INTO model (model_id, pipeline_tag, downloads, library_name, config) VALUES (%s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE pipeline_tag = values(pipeline_tag), downloads = values(downloads), library_name = values(library_name), config = values(config)
            # ''', (model_id, model.__dict__.get("pipeline_tag"), model.__dict__.get("downloads"), model.__dict__.get("library_name"), config))

            # conn.commit()
            # populate_card_repo(cursor, conn, model.id, "model", model)
            
            # populate_tags(cursor, conn, model.tags, model.modelId, "models")
            # populate_files(cursor, api, model.modelId, "model")
            # conn.commit() # Commit of files
            # populate_commits(cursor, conn, model.modelId, "models", process)
            # populate_discussions(cursor, conn, api, model.modelId, "model")


      print("Info retrieved! Gathered", total_datasets_count, "datasets")
      print(updated_datasets_count, "datasets updated!")
      print("Datasets population finished!")
      
def populate_spaces(cursor, conn, spaces_loaded_pkl, filter_m = None, part = "all", en_commit = True):
      """ 
      """
      found_filter = False
      conn.autocommit = True
      lst_update_table_spaces = []
      updated_spaces_count = total_spaces_count = 0
            
      print("Retrieving full information of spaces...")      
      print("Starting population into database...")
      
      for space in spaces_loaded_pkl:
            space_id = "spaces/" + space.get("id")
            total_spaces_count += 1
            
            if filter_m and not found_filter: # 
                  if filter_m == space_id:
                        found_filter = True
                        print(f"Found filter {filter_m}, processing...")
                        print(space_id)
                        continue
                  else:
                        print ("space_id: not processed", space_id)
                        continue
            
            print ("space_id:", space_id)

            if total_spaces_count % 1000 == 0:
                  print(total_spaces_count, "spaces processed...")

            # Gather just those with modifications within the limit_date (e.g., last month)
            lastModified= space.get("last_modified")
            dt_utc=  aux_hf.convert_to_utc(lastModified)
            created_at = space.get("created_at")
            dt_created_utc=  aux_hf.convert_to_utc(created_at)

            if part == "all" or part ==  "repository":
                  
                  if space.get("id") in []:#"AmirHussein/icefall-asr-mgb2-conformer_ctc-2022-27-06", "datablations/lm1-misc","tktkdrrrrrrrrrrr/CivitAI_model_info"]: # models fails
                        continue
                  
                  if (space.get("author") != None):
                        cursor.execute(aux_hf.give_SQL_pattern("HF_author"), (space.get("author"), "hf_owner"))
                        conn.commit()
            
                  gated = space.get("gated")
                  
                  if gated == False:
                        gated = 0
                  elif gated == "manual":
                        gated = 1
                  elif gated == "auto":
                        gated = 2

                  # * add securityStatus field 
                  cursor.execute(aux_hf.give_SQL_pattern("repository"), (space_id, space.get("id"), "dataset", space.get("author"), space.get("sha"), dt_utc, space.get("private"), str(space.get("cardData")), gated, space.get("likes"), space.get("disabled"), dt_created_utc))
                  
                  if part == "repository":
                        conn.commit()
                        
            if part == "all" or part == "space":
                  list_info_space = load_spaces_table(conn, cursor, space_id, space, en_commit = en_commit)
                  
                  if not en_commit:
                        lst_update_table_spaces.append(list_info_space)
            updated_spaces_count += 1
            
            if updated_spaces_count % GLOBAL_BATCH_SIZE == 0 and not en_commit:
                  if len(list_info_space) > 0:
                        conn.start_transaction()
                        aux_hf.insert_many(conn, aux_hf.give_SQL_pattern("space"), lst_update_table_spaces)
                        conn.commit()
                        lst_update_table_spaces.clear()
                  updated_spaces_count = 0
                  print(f"Committed up to the object {space_id} discussions so far...")
      
      if en_commit == False and updated_spaces_count > 0:
            conn.start_transaction()
            aux_hf.insert_many(conn, aux_hf.give_SQL_pattern("space"), lst_update_table_spaces)
            print("Final commit after processing all objects.")
            
      conn.commit()# Final commit for any remaining objects

            # cursor.execute('''
            # INSERT INTO model (model_id, pipeline_tag, downloads, library_name, config) VALUES (%s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE pipeline_tag = values(pipeline_tag), downloads = values(downloads), library_name = values(library_name), config = values(config)
            # ''', (model_id, model.__dict__.get("pipeline_tag"), model.__dict__.get("downloads"), model.__dict__.get("library_name"), config))

            # conn.commit()
            # populate_card_repo(cursor, conn, model.id, "model", model)
            
            # populate_tags(cursor, conn, model.tags, model.modelId, "models")
            # populate_files(cursor, api, model.modelId, "model")
            # conn.commit() # Commit of files
            # populate_commits(cursor, conn, model.modelId, "models", process)
            # populate_discussions(cursor, conn, api, model.modelId, "model")


      print("Info retrieved! Gathered", total_spaces_count, "spaces")
      print(updated_spaces_count, "Spaces updated!")
      print("Spaces population finished!")

def main(argv=None):
      print("Starting update main info...")
      args = parse_args(argv or sys.argv[1:])
      
      host, port, user, password, db_name, token = "", 3306, "", "", "", "NA"
      host, port, user, password, db_name, token = aux_hf.read_env_variables()

      if token == "NA":
            aux_hf.eprint("Missing token in env variables. Please add token in 'hfh_token' field.")
            sys.exit(1)
            
      if user == "" or password == "" or db_name == "":
            aux_hf.eprint("Missing database configuration in env variables. Please add DB_USER, DB_PASS and DB_NAME.")
            sys.exit(1)
      
      conn, database = aux_hf.create_connection_mysql(host, port, user, password, db_name)
      c = conn.cursor()
      if db_name != "hfd2_new":
            aux_hf.eprint("Database name is not 'hfd2_new'. Please check your env variables.")
            sys.exit(1)
      print("Database connection established!", "DB:", db_name)
            
      aux_hf.set_up_db(c, database)
      tables = aux_hf.check_database_schema(c, database)
          
      start_time = time.time()
      en_commit = True # manually defined this to have a trace in the code. 
      
      try:
            if len(tables)!= 0:
                  aux_hf.eprint("Some tables are missing in the database. Please, run first 'main.py' to create the database schema.")
                  aux_hf.eprint("Missing tables: ", tables)
                  sys.exit(1)
            
            
            # Settings to avoid formatting error when inserting text
            c.execute("SET NAMES utf8mb4")
            c.execute("SET CHARACTER SET utf8mb4")
            c.execute("SET character_set_connection=utf8mb4")
            c.execute("SET character_set_server=utf8mb4")
            #query = """ALTER DATABASE {} CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;""".format(DB_NAME)
            #c.execute(query)
            api = HfApi(token=token)
            # Import by type.
            if args.scope == "datasets":
                  print("Reading datasets from pickle")
                  datasets_loaded_pkl = aux_hf.load_pickle("/results/datasets_r2_10_09.pkl.gz")
                  print("Populating repository for datasets")
                  populate_datasets(c, conn, datasets_loaded_pkl, filter_m = None, part = "dataset", en_commit = en_commit)  # datasets/nvidia/PhysicalAI-Autonomous-Vehicles, TRUE              
            elif args.scope == "spaces":
                  print("Reading spaces from pickle")
                  spaces_loaded_pkl = aux_hf.load_pickle("/results/spaces_r2_10_09.pkl.gz")
                  print("Populating repository for spaces")
                  populate_spaces(c, conn, spaces_loaded_pkl, filter_m = None, part = "repository", en_commit = en_commit)
            elif args.scope == "models":
                  print("Reading models from pickle")
                  models_loaded_pkl = aux_hf.load_pickle("/results/models_r2_10_09.pkl.gz")
                  print("Populating repository for models")
                  populate_models(c, conn, models_loaded_pkl, filter_m = None, part = "model", en_commit = en_commit)
            elif args.scope =="all":
                  #populate_datasets(c, conn, api, limit_index, limit_date, update, process)
                  #populate_spaces(c, conn, api, limit_index, limit_date, update, process)
                  #populate_models(c, conn, api, limit_index, limit_date, update, process)
                  pass
      except Exception as e:
            conn.rollback()
            print("Error during the discussion info update process:\n", enumerate)
            aux_hf.eprint("Error during the discussion info update process:\n", sys.exc_info())
            print("Error details:\n", e)
            raise e
            #sys.exit(1)
      finally:
            conn.commit()
            c.close()
            conn.close()
      
      print("Discussion info update finished.")
      # Printing execution time...
      exec_time = time.time() - start_time
      print("\nExecution time:")
      print("--- %s seconds ---" % (exec_time))
      print("--- %s minutes ---" % (round(exec_time/60,2)))
      print("--- %s hours ---" % (round(exec_time/3600,2)))
      sys.exit(0)

if __name__ == "__main__":
    raise SystemExit(main())