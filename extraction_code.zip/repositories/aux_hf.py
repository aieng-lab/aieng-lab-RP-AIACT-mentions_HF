import os
import sys
import gzip, pickle


import requests
# time dependencies 
import pytz
import datetime


import mysql.connector
from mysql.connector import errorcode
MAX_TEXT = 65535  # TEXT; MEDIUMTEXT is 16777215, TINYTEXT is 255


def insert_many(conn, sql, rows):
    with conn.cursor() as cur:
        cur.executemany(sql, rows) 

def read_env_variables():
      """
      Function that retrieves coniguration for the script from env variables.
      """
      #global DB_HOST, DB_PORT, DB_USER, DB_PASS, DB_NAME, ACCESS_TOKEN#, SKIPPED_REPOS, NUM_COMMITS, NUM_FILES, LAST_N_MONTHS, LAST_MODIFIED

      host = os.getenv("DB_HOST", "db")
      port = int(os.getenv("DB_PORT", "3306"))
      user = os.getenv("DB_USER", "")
      password = os.getenv("DB_PASS", "")
      name = os.getenv("DB_NAME_NEW", "")
      token = os.getenv("ACCESS_TOKEN_F", "NA")
      return host, port, user, password, name, token

def create_connection_mysql(host, port, user, password, name):
      """ 
      Configures a database connection to a MySQL/MariaDB database.
      Database parameters must be located in the `env variables`.

      :return: Tuple containing the MySQL connector to the database specified in the cenv variables and the database name.
      :rtype: (`connection.MySQLConnection`_, str)
      """

      conn = None

      try :
            conn = mysql.connector.connect(user=user, password=password, host=host, port=port, database=name)
      except KeyError as ke:
            eprint("Missing some mandatory parameters in the env variables Don't forget to specify 'user', 'pass', 'host', 'port' and 'database'.")
            sys.exit(1)
      except mysql.connector.Error as err:
            if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
                  eprint("Error in connection to the MariaDB. Something is wrong with your user name or password.")
                  sys.exit(1)
            elif err.errno == errorcode.ER_BAD_DB_ERROR:
                  print("Database specified in the env variables does not exist. Creating such database...")
                  conn = mysql.connector.connect(user=user, password=password, host=host, port=port)
                  conn.cursor().execute(f"CREATE DATABASE IF NOT EXISTS {name};")
                  print("Database created!")
                  conn.cursor().execute(f"USE {name};")
            else:
                  eprint(err)
                  sys.exit(1)
      return conn, name


def set_up_db(cursor, database):
    """ Sets up the database schema. """
        
    # Settings to avoid formatting error when inserting text
    cursor.execute("SET NAMES utf8mb4")
    cursor.execute("SET CHARACTER SET utf8mb4")
    cursor.execute("SET character_set_connection=utf8mb4")
    cursor.execute("SET character_set_server=utf8mb4")
    query = """ALTER DATABASE {} CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;""".format(database)
    cursor.execute(query)
    
def check_database_schema(cursor, database):
    """
    Auxiliar function to check if all the tables required are in the database.

    :param cursor: The MySQL connection cursor to execute operations such as SQL statements.
    :type cursor: `cursor.MySQLCursor`_
    :param database: MariaDB database name.
    :type database: str
    """
    cursor.execute("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s", [database])
    db_tables = set(list(map(lambda x: x[0], cursor.fetchall())))

    hf_tables = set(["author", #"commit_parents",
                     "commits", "dataset", "discussion", #"conflicting_files_discussion",
                     "discussion_event", #"repo_file", "modified_file", "files_in_commit", 
                     "model", "repository", "tag", "tags_in_repo", "space", "datasets_in_space", "models_in_space", "repo_card","model_card", "data_card", "space_card"])
    return hf_tables - db_tables


         
def give_SQL_pattern(pattern_needed):
      if pattern_needed == "repository":
            return "INSERT INTO repository (id, name, type, author, sha, last_modified, private, card_data, gated, likes, disabled, create_date) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE name = values(name), type = values(type), author = values(author), sha = values(sha), last_modified= values(last_modified), private = values(private), card_data = values(card_data), gated = values(gated), likes = values(likes), disabled = values(disabled), create_date = values(create_date)"
      
      elif pattern_needed == "model_card":
            return "INSERT IGNORE INTO model_card (repo_id, base_model, eval_results, language, licence, license_name, license_link, datasets, metrics, pipeline_tag, model_name, downloads_all_time, tags, model_index) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE base_model = values(base_model), eval_results = values(eval_results), language = values(language), licence = values(licence), license_name = values(license_name), license_link = values(license_link), datasets = values(datasets), metrics = values(metrics), pipeline_tag = values(pipeline_tag), model_name = values(model_name), downloads_all_time = values(downloads_all_time), tags = values(tags), model_index = values(model_index)"

      elif pattern_needed == "repo_card":
            return "INSERT IGNORE INTO repo_card (repo_id, card_content, card_text, card_data) VALUES (%s, %s, %s, %s) ON DUPLICATE KEY UPDATE card_content = values(card_content), card_text = values(card_text), card_data = values(card_data)"

      elif pattern_needed == "dataset_card":
            return "INSERT IGNORE INTO data_card (repo_id, language, licence, annotations_creators, language_creators, source_datasets, paperswithcode_id, pretty_name, task_categories, task_ids, train_eval_index, downloads_all_time) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE language = values(language), licence = values(licence), annotations_creators = values(annotations_creators), language_creators = values(language_creators), source_datasets = values(source_datasets), paperswithcode_id = values(paperswithcode_id), pretty_name = values(pretty_name), task_categories = values(task_categories), task_ids = values(task_ids), train_eval_index = values(train_eval_index), downloads_all_time = values(downloads_all_time)"
      elif pattern_needed == "space_card":
            return  "INSERT IGNORE INTO space_card (repo_id, title, licence, duplicated_from, models, tags, datasets, downloads_all_time) VALUES (%s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE title = values(title), licence = values(licence), duplicated_from = values(duplicated_from), models = values(models), tags = values(tags), datasets = values(datasets), downloads_all_time = values(downloads_all_time)"
      
      elif pattern_needed == "discussion":
            return "INSERT INTO discussion (num, repo_id, author, title, status, created_at, is_pull_request, target_branch, merge_commit_oid, diff, git_reference) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE status = values(status), title = values(title)"
      
      
      elif pattern_needed == "hf_discussion_author" or pattern_needed == "hf_event_author":   
            return "INSERT IGNORE INTO author (username, avatar_url, is_pro, fullname, type, source) VALUES (%s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE avatar_url = values(avatar_url), is_pro = values(is_pro), fullname = values(fullname), type = values(type), source = values(source)"    
      
      
      elif pattern_needed == "commit_sha":
            return "INSERT IGNORE INTO commits (sha) VALUES (%s)"
      
      elif pattern_needed == "conflicts_discussion":
            return "INSERT IGNORE INTO conflicting_files_discussion (num, repo_id, filename, repo_file_id) VALUES (%s, %s, %s, %s)"
      elif pattern_needed == "comment_event":
            return "INSERT IGNORE INTO discussion_event (id, repo_id, discussion_num, event_type, created_at, author, content, edited, hidden, full_data) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
      elif pattern_needed == "commit_event":
            return "INSERT IGNORE INTO discussion_event (id, repo_id, discussion_num, event_type, created_at, author,summary, sha, full_data) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
      elif pattern_needed == "status_change_event":
            return "INSERT IGNORE INTO discussion_event (id, repo_id, discussion_num, event_type, created_at, author, new_status, full_data) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
      elif pattern_needed == "title_change_event":
            return "INSERT IGNORE INTO discussion_event (id, repo_id, discussion_num, event_type, created_at, author, old_title, new_title, full_data) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
      elif pattern_needed == "HF_author":   
            return "INSERT IGNORE INTO author (username, source) VALUES (%s, %s) ON DUPLICATE KEY UPDATE avatar_url = values(avatar_url), source = CONCAT_WS(',', source, VALUES(source))"
     
      elif pattern_needed == "model":
            return "INSERT INTO model (model_id, pipeline_tag, downloads, library_name, config) VALUES (%s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE pipeline_tag = values(pipeline_tag), downloads = values(downloads), library_name = values(library_name), config = values(config)"
      
      elif pattern_needed == "dataset":
            return "INSERT INTO dataset (dataset_id, description, citation, paperswithcode_id, downloads, pipeline_tag) VALUES (%s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE description = values(description), citation = values(citation), paperswithcode_id = values(paperswithcode_id), downloads = values(downloads), pipeline_tag = values(pipeline_tag)"
      elif pattern_needed == "space":
            return "INSERT INTO space (space_id, sdk, trending_score, storage, runtime_raw, tags) VALUES (%s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE sdk = values(sdk), trending_score = values(trending_score), storage = values(storage), runtime_raw = values(runtime_raw), tags = VALUES(tags)"
      
                                    
      
      
def convert_to_utc(date_to_convert):
    """Convert a datetime string or datetime to timezone-aware UTC."""
    if date_to_convert is None:
        return None

    if isinstance(date_to_convert, str):
        date_to_convert = datetime.datetime.fromisoformat(date_to_convert)

    if date_to_convert.tzinfo is None:
        return date_to_convert.replace(tzinfo=datetime.timezone.utc)
    return date_to_convert.astimezone(datetime.timezone.utc)

def too_long(value, limit=MAX_TEXT):
    if value is None:
        return False
    if len(str(value).encode('utf-8')) > limit:
          return "TOO LONG, check gz"
    else:
          return value
        
def eprint(*args, **kwargs):
      """
      Auxiliar function to print errors to stderr.
      """
      print(*args, file=sys.stderr, **kwargs)
      
      
def load_pickle(name = "models.pkl.gz"):
    with gzip.open(name, "rb") as f:
        infos = pickle.load(f)
    return infos


def define_session() -> requests.Session:
    session = requests.Session()
    return session


def is_retryable_http_error(e: Exception) -> bool:
    if isinstance(e, requests.HTTPError) and e.response is not None:
        return e.response.status_code in (429, 500, 502, 503, 504) # if an error is server related or rate limiting
    # Network / transient errors
    return isinstance(e, (requests.ConnectionError, requests.Timeout))

def parse_ratelimit(resp: requests.Response)-> int | None:
    # (just for ana) Example: '"api";r=2499;t=292' HUgging face response
    
    headers = resp.headers
    str_rate = headers.get("ratelimit", None) or headers.get("RateLimit", None) or headers.get("Ratelimit", None) 
    info_limit = {}
    info_limit['time'] = None
    info_limit['left_rq'] = None
    print("HEADERS", headers)
    print(f"Ratelimit header: {str_rate} !")
    if not str_rate:
        return info_limit
  
    for policy in map(str.strip, str_rate.split(";")):  
      aplit_eq = policy.split("=")
      
      if len(aplit_eq) < 2:
            continue
      else:
            if aplit_eq[0].strip().lower() == "r":
                  info_limit['left_rq'] = int(aplit_eq[1].strip())
            elif aplit_eq[0].strip().lower() == "t":
                  info_limit['time'] = int(aplit_eq[1].strip())
    return info_limit # dict that contains remaining requests and time to reset


def wait_for_reset(retry_state) -> float:
    """
    Tenacity will call this with retry_state.
    If last exception was HTTPError, read headers and return sleep seconds.
    Otherwise return a small, growing fallback.
    """
    e = retry_state.outcome.exception() if retry_state.outcome else None
    if isinstance(e, requests.HTTPError) and e.response is not None:
        secs = parse_ratelimit(e.response)["time"]
        if secs is not None:
            return float(secs)
    # fallback: linear up to 30s
    return min(5.0 * retry_state.attempt_number, 30.0) # from 5 to 30 seconds if seconds were not able to be retrieved