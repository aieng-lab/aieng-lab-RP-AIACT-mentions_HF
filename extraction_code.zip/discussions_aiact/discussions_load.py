from modulefinder import test
import sys
import argparse
from urllib.error import HTTPError

import requests
from typing import Tuple, Dict
from tenacity import retry, stop_after_attempt, retry_if_exception

import hashlib
import json
import aux_hf


from huggingface_hub.utils import (
    HfHubHTTPError,
    RepositoryNotFoundError
    )

HOME = "https://huggingface.co"

ACCESS_TOKEN ="NA"
GLOBAL_BATCH_SIZE = 100

def parse_args(argv):
    parser = argparse.ArgumentParser(description="Manage database schema and basic info.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-s", "--scope", choices=["datasets", "models", "spaces"],
                       default="models",help="Load basic information to some.")
    
    return parser.parse_args(argv)
    
def insert_many(conn, sql, rows):
    with conn.cursor() as cur:
        cur.executemany(sql, rows) 
        
def define_url_discussions(repo_type,repo_id,*, detail = False, num = 0):
    """
    Define the URL of the README file for a given model.
    """
    url = ""
    params = {}
    if not detail:
        url = f"{HOME}/api/{repo_type}/{repo_id}/discussions"
        params = {"type": "all", "status":"all", "p":num }
    else:
        url = f"{HOME}/api/{repo_type}/{repo_id}/discussions/{num}"
        params = {"diff": "1"}
    return url, params


@retry(
    retry=retry_if_exception(aux_hf.is_retryable_http_error),
    wait=aux_hf.wait_for_reset,                
    stop=stop_after_attempt(10),
    reraise=True,
)
def fetch_discussions(url: str, session: requests.Session, timeout: float= 30, params: dict={}, token: str="") -> Tuple[Dict, bool]: 
    # Inspired by https://github.com/huggingface/huggingface_hub/blob/v0.36.0/src/huggingface_hub/hf_api.py#L6152
    headers = {"Authorization": f"Bearer {token}"} if token != "" else {}
    resp = session.get(url, params=params, timeout=timeout, headers=headers)
    resp.raise_for_status()
    
    resp = resp.json()
    count = resp.get("count", 0)
    start = resp.get("start", 0)
    discussions = resp.get("discussions", [])
    has_next = (start + len(discussions)) < count
    
    return discussions, has_next


@retry(
    retry=retry_if_exception(aux_hf.is_retryable_http_error),
    wait=aux_hf.wait_for_reset,                
    stop=stop_after_attempt(10),
    reraise=True,
)
def fetch_discussion_details(url: str, session: requests.Session, timeout= (10, 90), params: dict={}, token: str="") -> Dict: 
    headers = {"Authorization": f"Bearer {token}"} if token != "" else {}
    resp = session.get(url, params=params, timeout=timeout, headers=headers)
    resp.raise_for_status()
    
    return resp.json()

def insert_authors(object, cursor, conn, diss_type, lst_authors_discussion, en_commit = True):
    """
    Insert author into the database if not already present.
    """
    
    author_name = object.get("author", {}).get("name", "deleted")
    # author of the discussion was deleted therefore, it oes not have a name assigned anymore
    avatar_url = None
    is_pro = None
    fullname = None
    type_author = None
    
    
    if object:
        avatar_url = object.get("avatarUrl", None)
        is_pro = object.get("isPro", None)
        fullname = object.get("fullname", None)
        type_author = object.get("type", None)
 
    if en_commit and object:
        cursor.execute(aux_hf.give_SQL_pattern(diss_type), (author_name, avatar_url, is_pro, fullname, type_author, "hf_discussion_author"))
        conn.commit()
    elif not en_commit and object:
        lst_authors_discussion.append( (author_name, avatar_url, is_pro, fullname, type_author, diss_type) )

    # print(f"NAME INSERT AUTHORS FUNCT {author_name}")
    return (author_name, avatar_url, is_pro, fullname, type_author, diss_type)
    

def insert_simple_commit_sha(sha: str, cursor, conn, lst_commits_sha,  en_commit = True):
    """
    Insert commit sha into the database if not already present.
    """
    if en_commit and sha:
        cursor.execute(aux_hf.give_SQL_pattern("commit_sha"), (sha,))
        conn.commit()
    elif not en_commit and sha:
        lst_commits_sha.append( (sha,) ) # in acase of error remove tuple
    return sha

def insert_conflicting_files_in_discussion(num: int, repo_type:str, repo_id: str, file: list, repo_file_id:str, cursor, conn, lst_conflicting_files, en_commit = True):
    
    if en_commit:
        cursor.execute(aux_hf.give_SQL_pattern("conflicts_discussion"), (num, repo_type+"/"+repo_id, file, repo_file_id))
        conn.commit()
    else:
        lst_conflicting_files.append( (num, repo_type+"/"+repo_id, file, repo_file_id) )
    return num, repo_type+"/"+repo_id, file, repo_file_id

def insert_discussions(num, repo_type, repo_id, author_name, title, status, createdAt, is_pull_request, target_branch, merge_commit_oid, diff, git_reference, cursor, conn, lst_discussions, en_commit = True):
   
    createdAt = aux_hf.convert_to_utc(createdAt)
    #print(f"AUTHOR IN INSERT DISCUSSION {author_name}")
    
    if en_commit:
        cursor.execute(aux_hf.give_SQL_pattern("discussion"), (num, repo_type+"/"+repo_id, author_name, title, status, createdAt, is_pull_request, target_branch, merge_commit_oid, diff, git_reference))
        conn.commit()
    else:
        lst_discussions.append( (num, repo_type+"/"+repo_id, author_name, title, status, createdAt, is_pull_request, target_branch, merge_commit_oid, diff, git_reference) )
    return (num, repo_type+"/"+repo_id, author_name, title, status, createdAt, is_pull_request, target_branch, merge_commit_oid, diff, git_reference)

def insert_comment_event(object, repo_type, repo_id, num, cursor, conn, lst_comments_events, en_commit = True):
    
    event_id = None #
    repo_id = repo_type + '/' + repo_id
    event_type = "comment"
    created_at = None #
    author_name = None #
    content = None #
    edited = None #
    hidden = None #
    event_data = None #
    
    if object: 
        event_id = object.get("id") 
        created_at = object.get("createdAt")        
        created_at = aux_hf.convert_to_utc(created_at)
        author_name = object.get("author", {}).get("name", "deleted")
        edited= object.get("data").get("edited")
        hidden= object.get("data").get("hidden")
        content=object.get("data").get("latest").get("raw")
        event_data = str(object)
    
    if en_commit and object:
        # print(f"Inserting comment event: {event_id}, {repo_id}, {num}")
        
        if num == 43 and repo_id == "models/circlestone-labs/Anima" and event_id == "6988837a48ae527366910e85":
            print(f"Inserting comment event: {event_id}, {repo_id}, {num}")
            cursor.execute(aux_hf.give_SQL_pattern("comment_event"), event_data)
        else:  
            cursor.execute(aux_hf.give_SQL_pattern("comment_event"), (event_id, repo_id, num, event_type, created_at, author_name, content, edited, hidden, event_data))
        conn.commit()
    elif not en_commit and object:
        lst_comments_events.append( (event_id, repo_id, num, event_type, created_at, author_name, content, edited, hidden, event_data) )
       
    return (event_id, repo_id, num, event_type, created_at, author_name, content, edited, hidden, event_data)


def insert_commit_event(object, repo_type, repo_id, num, cursor, conn, lst_commits_events, en_commit = True):
    
    event_id = None #
    repo_id = repo_type + '/' + repo_id
    event_type = "commit"
    created_at = None #
    title = None    
    
    summary = None 
    oid = None
    
    author_name = None #
    event_data = None #
    
    if object: 
        event_id = object.get("id") 
        created_at = object.get("createdAt")        
        created_at = aux_hf.convert_to_utc(created_at)
        author_name = object.get("author", {}).get("name", "deleted")
        summary = object.get("data").get("subject")
        oid = object.get("data").get("oid")
        event_data = str(object)
             
    # commit_event
    if en_commit and object:
        cursor.execute(aux_hf.give_SQL_pattern("commit_event"), (event_id, repo_id, num, event_type, created_at, author_name, summary, oid, event_data))
        conn.commit()
    elif not en_commit and object:
        lst_commits_events.append((event_id, repo_id, num, event_type, created_at, author_name, summary, oid, event_data))
       
    return (event_id, repo_id, num, event_type, created_at, author_name, summary, oid, event_data)

def insert_status_change_event(object, repo_type, repo_id, num, cursor, conn, lst_status_change_events, en_commit = True):
    
    event_id = None #
    repo_id = repo_type + '/' + repo_id
    event_type = "status-change"
    created_at = None #
    
    new_status = None 
        
    author_name = None #
    event_data = None #
    
    if object: 
        event_id = object.get("id") 
        created_at = object.get("createdAt")        
        created_at = aux_hf.convert_to_utc(created_at)
        author_name = object.get("author", {}).get("name", "deleted")
        event_data = str(object)

    # status-change
    if en_commit and object:
        cursor.execute(aux_hf.give_SQL_pattern("status_change_event"), (event_id, repo_id, num, event_type, created_at, author_name, new_status, event_data))
        conn.commit()        
    elif not en_commit and object:
        lst_status_change_events.append((event_id, repo_id, num, event_type, created_at, author_name, new_status, event_data))
       
    return (event_id, repo_id, num, event_type, created_at, author_name, new_status, event_data)

def insert_title_change_event(object, repo_type, repo_id, num, cursor, conn, lst_title_change_events, en_commit = True):
    event_id = None #
    repo_id = repo_type + '/' + repo_id
    event_type = "title-change"
    created_at = None #
    
    old_title = None 
    new_title = None
        
    author_name = None #
    event_data = None #
    
    if object: 
        event_id = object.get("id") 
        created_at = object.get("createdAt")        
        created_at = aux_hf.convert_to_utc(created_at)
        author_name = object.get("author", {}).get("name", "deleted")
        event_data = str(object)
        
        old_title = object.get("data").get("from")
        new_title = object.get("data").get("to")

    # title-change
    if en_commit and object:
        cursor.execute(aux_hf.give_SQL_pattern("title_change_event"), (event_id, repo_id, num, event_type, created_at, author_name, old_title, new_title, event_data))
        conn.commit()        
        
    elif not en_commit and object:
        lst_title_change_events.append((event_id, repo_id, num, event_type, created_at, author_name, old_title, new_title, event_data))
       
    return (event_id, repo_id, num, event_type, created_at, author_name, old_title, new_title, event_data)



def load_discussions(cursor, conn, repo_type, repo_id, token, en_commit=True):
    discussions = None
    has_next, page = True, 0
    lst_authors_discussion, lst_commits_sha, lst_discussions, lst_conflicting_files = [], [], [], []
    lst_commits_events, lst_comments_events, lst_status_change_events, lst_title_change_events = [], [], [], []
    
    while has_next:
        
        url, params = define_url_discussions(repo_type, repo_id, detail=False, num=page) # num = page 0
        try:
            # print(f"Fetching discussions for {repo_type} {repo_id} page {page}...")
            discussions, has_next = fetch_discussions(url, aux_hf.define_session(), params=params, token=token)
            # EXCEPTION 
        except requests.exceptions.HTTPError as e:
            aux_hf.eprint(f"DISCUSSIONS Error fetching for {repo_type} {repo_id} discussion {page}: {str(e)}") 
            if e.response is not None and e.response.status_code == 429:
                raise e
            return (lst_authors_discussion, lst_commits_sha, lst_discussions, lst_conflicting_files, lst_commits_events, lst_comments_events, lst_status_change_events, lst_title_change_events) 

            # aux_hf.eprint(f"Error fetching discussions for {repo_type} {repo_id}: {str(e)}")
        
        for discussion in discussions:
            num = discussion.get("num", None)
            url, params = define_url_discussions(repo_type, repo_id, detail=True, num=num) # num = discussion ID 0
            if repo_id == "Symato/cc":
                print("number of discussion:", num)
            #
            try:
                # print(f"Fetching discussion details for {repo_type} {repo_id} discussion {num}...")
                if repo_type == "datasets" and repo_id == "nvidia/PhysicalAI-Autonomous-Vehicles" and num == 12:
                    continue # this discussion has a problem with the details, and it is not possible to fetch it. It is a known issue in the dataset
                details_disc = fetch_discussion_details(url, aux_hf.define_session(), params=params, token=token)
            except requests.exceptions.HTTPError as e:
                aux_hf.eprint(f"DETAILS Error fetching for {repo_type} {repo_id} discussion {num}: {str(e)}") 
                if e.response is not None and e.response.status_code == 429:
                    aux_hf.eprint(f"DISCUSSIONS details Error fetching for {repo_type} {repo_id} discussion {page}: {str(e)}") 
                    raise e
                continue
            except requests.exceptions.ReadTimeout as e:
                aux_hf.eprint(f"DETAILS ReadTimeout Error fetching for {repo_type} {repo_id} discussion {num}: {str(e)}") 
                
                if (num == 76 and repo_id == "ibrahimhamamci/CT-RATE") or (num == 2 and repo_id == "daisuke9999/comment") or (repo_id == "google/gemma-3-4b-it" and num == 69):
                    aux_hf.eprint("Skipping known problematic discussions in datasets")
                    continue
                else:
                    raise e
                
            # EXCEPTION aux_hf.eprint(f"Error fetching discussion details for {repo_type} {repo_id} discussion {num}: {str(e)}")        
        
            is_pull_request = details_disc["isPullRequest"]
            target_branch = details_disc["changes"]["base"] if is_pull_request else None
            #conflicting_files = details_disc["filesWithConflicts"] if is_pull_request else None
            merge_commit_oid = details_disc["changes"].get("mergeCommitId", None) if is_pull_request else None
            
            author_name, _, _, _, _, _ = insert_authors(discussion, cursor, conn, "hf_discussion_author", lst_authors_discussion, en_commit=en_commit)
            merge_commit_oid = insert_simple_commit_sha(merge_commit_oid, cursor, conn, lst_commits_sha,en_commit=en_commit) # we are not checking if it exists due to privat repo. In the case that this is the case, after populating the commit table this will be empty 
            
            title = details_disc.get("title", None)
            status = details_disc.get("status", None)
            createdAt = details_disc.get("createdAt", None)
            diff = details_disc.get("diff", None)
            git_reference = details_disc.get("gitReference", None)
            
            insert_discussions(num, repo_type, repo_id, author_name, title, status, createdAt, is_pull_request, target_branch, merge_commit_oid, diff, git_reference, cursor, conn, lst_discussions, en_commit=en_commit)
                
                
            # Insert events if any
            for event in details_disc.get("events", []):
                author_name, _, _, _, _, _ = insert_authors(event, cursor, conn, "hf_event_author", lst_authors_discussion, en_commit = en_commit)
                
                event_type = event.get("type")
                
                if event_type == "comment":
                    insert_comment_event(event, repo_type, repo_id, num, cursor, conn, lst_comments_events, en_commit = en_commit)
                elif event_type == "status-change":
                    insert_status_change_event(event, repo_type, repo_id, num, cursor, conn, lst_status_change_events, en_commit = en_commit)
                elif event_type == "commit":
                    insert_commit_event(event, repo_type, repo_id, num, cursor, conn, lst_commits_events, en_commit = en_commit)
                elif event_type == "title-change":
                    insert_title_change_event(event, repo_type, repo_id, num, cursor, conn, lst_title_change_events, en_commit = en_commit)
                        
        page = page + 1
                    
    return (lst_authors_discussion, lst_commits_sha, lst_discussions, lst_conflicting_files, lst_commits_events, lst_comments_events, lst_status_change_events, lst_title_change_events)    


def populate_discussions(conn, cursor, repo_type, lst_object, token, filter = None, en_commit = True):
    
    found_filter = False
    conn.autocommit = en_commit
    
    print("en commit is set to:", en_commit)
    
    #variables useful when auto commit is false, and we are committing every GLOBAL_BATCH_SIZE objects
    lst_authors_discussion, lst_commits_sha, lst_discussions, lst_conflicting_files, lst_commits_events, lst_comments_events, lst_status_change_events, lst_title_change_events = [], [], [], [], [], [], [], []
    updated_objects = 0
    
    for obj in lst_object:
        object_id = obj.get("id")
        print(f"Processing {repo_type}/{object_id}, {updated_objects} objects updated so far..., en_commit is {en_commit}")
               
        if filter and not found_filter:
            if filter == object_id: # models/ATH-MaaS/OvisOCR2
                found_filter = True
                print(f"Found filter {filter}, processing...")
                print(object_id)
                continue
            else:
                continue
             
        try:        
            lst_auth, lst_cmmits, lst_disc, lst_confl, lst_commit_ev, lst_commet_ev, lst_stus_ev,lst_titl_ev = load_discussions(cursor, conn, repo_type, object_id, token, en_commit=en_commit)
        except HfHubHTTPError as e:
            aux_hf.eprint(f"for {object_id} HuggingFace API returned an error.HRRP not FOUND ERROR: {str(e)}")
            if e.response is not None and e.response.status_code == 429:
                print("ERROR discussions 429")
                raise e
            continue
        except RepositoryNotFoundError as ex:
            aux_hf.eprint(f"The repository {object_id} to download from cannot be found. This may be because it does not exist, or because it is set to private and you do not have access. REPO not FOUND ERROR: {str(e)}")
            continue
        
        if not en_commit:
            if len(lst_auth) > 0:
                lst_authors_discussion.extend(lst_auth)
            if len(lst_cmmits) > 0:
                lst_commits_sha.extend(lst_cmmits)
            if len(lst_disc) > 0:
                lst_discussions.extend(lst_disc)
            # if len(lst_confl) > 0:
            #     lst_conflicting_files.extend(lst_confl)
            if len(lst_commit_ev) > 0:
                lst_commits_events.extend(lst_commit_ev)
            if len(lst_commet_ev) > 0:
                lst_comments_events.extend(lst_commet_ev)
            if len(lst_stus_ev) > 0:
                lst_status_change_events.extend(lst_stus_ev)
            if len(lst_titl_ev) > 0:
                lst_title_change_events.extend(lst_titl_ev)
        
        updated_objects += 1
        if updated_objects % GLOBAL_BATCH_SIZE == 0 and not en_commit:
            # conn.start_transaction()
            
            insert_many(conn, aux_hf.give_SQL_pattern("hf_discussion_author"), lst_authors_discussion) #1
            insert_many(conn, aux_hf.give_SQL_pattern("commit_sha"), lst_commits_sha) #2
            insert_many(conn, aux_hf.give_SQL_pattern("discussion"), lst_discussions) #3
            # insert_many(conn, aux_hf.give_SQL_pattern("conflicts_discussion"), lst_conflicting_files) #4
            insert_many(conn, aux_hf.give_SQL_pattern("commit_event"), lst_commits_events) #5
            insert_many(conn, aux_hf.give_SQL_pattern("comment_event"), lst_comments_events) #6
            insert_many(conn, aux_hf.give_SQL_pattern("status_change_event"), lst_status_change_events) #7
            insert_many(conn, aux_hf.give_SQL_pattern("title_change_event"), lst_title_change_events) #8
            conn.commit()  # Commit changes to DB every GLOBAL_BATCH_SIZE objects
            
            #clear lists and reset counter
            updated_objects = 0
            lst_auth.clear()
            lst_cmmits.clear()
            lst_disc.clear()
            lst_confl.clear()
            lst_commit_ev.clear()
            lst_commet_ev.clear() 
            lst_stus_ev.clear() 
            lst_titl_ev.clear()
            
            lst_authors_discussion.clear()
            lst_commits_sha.clear()
            lst_discussions.clear()
            lst_conflicting_files.clear()
            lst_commits_events.clear()
            lst_comments_events.clear()
            lst_status_change_events.clear()
            lst_title_change_events.clear()
            print(f"Committed up to the object {object_id} discussions so far...")
    
    if en_commit == False and updated_objects > 0:
        # conn.start_transaction()
        insert_many(conn, aux_hf.give_SQL_pattern("hf_discussion_author"), lst_authors_discussion) #1
        insert_many(conn, aux_hf.give_SQL_pattern("commit_sha"), lst_commits_sha) #2
        insert_many(conn, aux_hf.give_SQL_pattern("discussion"), lst_discussions) #3 
        insert_many(conn, aux_hf.give_SQL_pattern("commit_event"), lst_commits_events) #5
        insert_many(conn, aux_hf.give_SQL_pattern("comment_event"), lst_comments_events) #6
        insert_many(conn, aux_hf.give_SQL_pattern("status_change_event"), lst_status_change_events) #7
        insert_many(conn, aux_hf.give_SQL_pattern("title_change_event"), lst_title_change_events) #8
        conn.commit()  # Commit changes to DB every GLOBAL_BATCH_SIZE objects
        print("Final commit after processing all objects.")
    else:
        conn.commit()  # Final commit for any remaining objects

    
def main(argv=None):
    print("Starting update discussion info...")
    args = parse_args(argv or sys.argv[1:])
    
    host, port, user, password, db_name, token = "", 3306, "", "", "", "NA"
    host, port, user, password, db_name, token = aux_hf.read_env_variables()

    if token == "NA":
        aux_hf.eprint("Missing token in env variables. Please add token in 'hfh_token' field.")
        sys.exit(1)
        
    if user == "" or password == "" or db_name == "":
        aux_hf.eprint("Missing database configuration in env variables. Please add DB_USER, DB_PASS and DB_NAME.")
        sys.exit(1)
    
    conn, database = aux_hf.create_connection_mysql(host, port, user, password, db_name)
    c = conn.cursor()
    
    aux_hf.set_up_db(c, database)
    tables = aux_hf.check_database_schema(c, database)
    
    try:
        if len(tables)!= 0:
            aux_hf.eprint("Some tables are missing in the database. Please, run first 'main.py' to create the database schema.")
            sys.exit(1)
        
        en_commit = False # manually defined this
        if args.scope == "datasets": # FALSE
            print("Reading datasets from pickle")
            datasets_loaded_pkl = aux_hf.load_pickle("/results/datasets_r2_10_09.pkl.gz")
            print("Populating Discussions for datasets", len(datasets_loaded_pkl))
            populate_discussions(conn, c, "datasets", datasets_loaded_pkl, token, filter = None, en_commit = False) 
            
        elif args.scope == "models": # FALSE           
            print("Reading models from pickle")
            models_loaded_pkl = aux_hf.load_pickle("/results/models_r2_10_09.pkl.gz")
            print("Populating Discussions for models")
            populate_discussions(conn, c, "models", models_loaded_pkl, token, filter= None, en_commit = en_commit) 
            
        elif args.scope == "spaces":   # FALSE         
            print("Reading spaces from pickle")
            spaces_loaded_pkl = aux_hf.load_pickle("/results/spaces_r2_10_09.pkl.gz")
            print("Populating Discussions for spaces")
            populate_discussions(conn, c, "spaces", spaces_loaded_pkl, token, filter = None, en_commit = en_commit) 
           
    except Exception as e:
        conn.rollback()
        aux_hf.eprint("Error during the discussion info update process:\n", sys.exc_info())
        raise e
        #sys.exit(1)
    finally:
        conn.commit()
        c.close()
        conn.close()
    
    print("Discussion info update finished.")
    sys.exit(0)

if __name__ == "__main__":
    raise SystemExit(main())