# System dependencies
import sys
import argparse

#import own dependencies
import aux_hf

# Third party dependencies regarding HTTP requests and retries
import requests
from tenacity import retry, stop_after_attempt, retry_if_exception

import json
# HuggingFace dependencies
from huggingface_hub.repocard import RepoCard
from huggingface_hub.utils import (
    EntryNotFoundError
    )

HOME = "https://huggingface.co"

ACCESS_TOKEN ="NA"
GLOBAL_BATCH_SIZE = 100


def parse_args(argv):
    parser = argparse.ArgumentParser(description="Manage database schema and basic info.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-s", "--scope", choices=["all", "datasets", "models", "spaces"],
                       default="all",help="Load basic information to some.")
   
    return parser.parse_args(argv)

def define_url_readme(repo_type: str, repo_id: str) -> str:
    """
    Define the URL of the README file for a given model.
    """
    if repo_type != "models":
        repo_id = repo_type + "/" + repo_id

    url = f"{HOME}/{repo_id}/resolve/main/README.md"

    return url

@retry(
    retry=retry_if_exception(aux_hf.is_retryable_http_error),
    wait=aux_hf.wait_for_reset,                
    stop=stop_after_attempt(10),
    reraise=True,
)
def fetch_data(url: str, session: requests.Session, timeout: float= 30, token: str="") -> requests.Response:
    headers = {"Authorization": f"Bearer {token}"} if token != "" else {}
    resp = session.get(url, timeout=timeout, headers=headers)
    resp.raise_for_status()
    return resp.text, dict(resp.headers)


def converter_json(object_tc):
    """ 
    Converts an object to a JSON string.
    
    :param object: The object to convert.
    :type object: Any
    :return: A JSON string representation of the object.
    :rtype: str
    """
    if isinstance(object_tc, (list, dict)) :
        if object_tc :
                object_tc = json.dumps(object_tc, ensure_ascii=False, separators=(",", ":"), default=str)
        else :
                object_tc = None
                
    return object_tc

def insert_many(conn, sql, rows):
    with conn.cursor() as cur:
        cur.executemany(sql, rows) 


def populate_model_card(cursor, conn, repo_name, repo_card_data, model, en_commit=True):
    """ 
    Importation of repo information. 
    It inserts card information into the ```model_card`` table.
    
    :param cursor: The MySQL connection cursor to execute operations such as SQL statements.
    :type cursor: `cursor.MySQLCursor`_
    :param conn: The MySQL connector to the database specified in the env variables. Used to commit changes to fulfill FK restrictions.
    :type conn: `connection.MySQLConnection`_
    :param repo_name: The full name (i.e., "owner/repo_name") of the repository.
    :type repo_name: str
    :param repo_card_data: The Repository card data that contains the information of the model
    :type repo_type: Card data
    """
        
    base_model = None 
    eval_results = None
    language = None
    licence = None
    licence_name = None
    licence_link = None
    datasets = None
    metrics = None
    tags = None
    model_index = None
    model_name = None
    downloads_all_time = None
    pipeline_tag = None
    try:
        if repo_card_data:
            base_model = converter_json(getattr(repo_card_data, "base_model", None))
            eval_results = converter_json(getattr(repo_card_data, "eval_results", None))
            language = converter_json(getattr(repo_card_data, "language", None))
            licence = converter_json(getattr(repo_card_data, "license", None))
            licence_name = converter_json(getattr(repo_card_data, "license_name", None))
            licence_link = converter_json(getattr(repo_card_data, "license_link", None))
            datasets = converter_json(getattr(repo_card_data, "datasets", None))
            metrics = converter_json(getattr(repo_card_data, "metrics", None))
            tags = converter_json(getattr(repo_card_data, "tags", None))
            model_index = converter_json(getattr(repo_card_data, "model_index", None))
            model_name = converter_json(getattr(repo_card_data, "model_name", None))
            downloads_all_time = converter_json(getattr(model, "downloads_all_time", None))
            pipeline_tag = converter_json(getattr(repo_card_data, "pipeline_tag", None))
            
            if en_commit:
                
                cursor.execute(aux_hf.give_SQL_pattern("model_card"), ("models/" + repo_name, base_model, eval_results, language, licence, licence_name, licence_link, datasets, metrics, pipeline_tag, model_name, downloads_all_time, tags, model_index))

        else:
            downloads_all_time = converter_json(getattr(model, "downloads_all_time", None))

            if en_commit:
                cursor.execute(aux_hf.give_SQL_pattern("model_card"), ("models/" + repo_name, None, None, None, None, None, None, None, None, None, None, downloads_all_time, None, None)) 
                       
        if en_commit:
            conn.commit()
        return ("models/" + repo_name, base_model, eval_results, language, licence, licence_name, licence_link, datasets, metrics, pipeline_tag, model_name, downloads_all_time, tags, model_index)
    
    except Exception as e:
        aux_hf.eprint("\n") 
        aux_hf.eprint("Error (model): " + repo_name + "): \n", sys.exc_info())
        raise e

def populate_space_card(cursor, conn, repo_name, repo_card_data, space, en_commit=True):
    """ 
    Importation of repo information. 
    It inserts card information into the ```model_card`` table.
    
    :param cursor: The MySQL connection cursor to execute operations such as SQL statements.
    :type cursor: `cursor.MySQLCursor`_
    :param conn: The MySQL connector to the database specified in the env variables. Used to commit changes to fulfill FK restrictions.
    :type conn: `connection.MySQLConnection`_
    :param repo_name: The full name (i.e., "owner/repo_name") of the repository.
    :type repo_name: str
    :param repo_card_data: The Repository card data that contains the information of the model
    :type repo_type: Card data
    """
    licence = None
    models = None
    tags = None
    datasets = None
    title = None
    duplicated_from = None
    downloads_all_time = None
    
    try:
        if repo_card_data:
            licence = converter_json(getattr(repo_card_data, "license", None))
            models = converter_json(getattr(repo_card_data, "models", None))
            tags = converter_json(getattr(repo_card_data, "tags", None))
            datasets = converter_json(getattr(repo_card_data, "datasets", None))
            title = converter_json(getattr(repo_card_data, "title", None))
            duplicated_from = converter_json(getattr(repo_card_data, "duplicated_from", None))
            downloads_all_time = converter_json(getattr(space, "downloads_all_time", None))
            
            if en_commit:
                cursor.execute(aux_hf.give_SQL_pattern("space_card"), ("spaces/" + repo_name, title, licence, duplicated_from, models, tags, datasets, downloads_all_time))
                
        else:
            downloads_all_time = converter_json(getattr(space, "downloads_all_time", None))
            
            if en_commit:
                cursor.execute(aux_hf.give_SQL_pattern("space_card"), ("spaces/" + repo_name, None, None, None, None, None, None, downloads_all_time))   
        
        if en_commit:
            conn.commit()
        return ("spaces/" + repo_name, title, licence, duplicated_from, models, tags, datasets, downloads_all_time)
    
    except Exception as e:
        aux_hf.eprint("\n") 
        aux_hf.eprint("Error (space): " + repo_name + "): \n", sys.exc_info())
        raise e  
    
def populate_dataset_card(cursor, conn, repo_name, repo_card_data, dataset, en_commit=True):
    """ 
    Importation of repo information. 
    It inserts card information into the ``data_card`` table.
    
    :param cursor: The MySQL connection cursor to execute operations such as SQL statements.
    :type cursor: `cursor.MySQLCursor`_
    :param conn: The MySQL connector to the database specified in the env variables. Used to commit changes to fulfill FK restrictions.
    :type conn: `connection.MySQLConnection`_
    :param repo_name: The full name (i.e., "owner/repo_name") of the repository.
    :type repo_name: str
    :param repo_card_data: The Repository card data that contains the information of the model
    :type repo_type: Card data
    """
    
    language = None
    licence = None
    annotations_creators = None
    language_creators = None
    source_datasets = None
    paperswithcode_id = None
    task_ids = None
    task_categories = None
    train_eval_index = None
    prettty_name = None
    downloads_all_time = None

    try:
        if repo_card_data:
            language = converter_json(getattr(repo_card_data, "language", None))
            licence = converter_json(getattr(repo_card_data, "license", None))
            annotations_creators = converter_json(getattr(repo_card_data, "annotations_creators", None))
            language_creators = converter_json(getattr(repo_card_data, "language_creators", None))
            source_datasets = converter_json(getattr(repo_card_data, "source_datasets", None))
            paperswithcode_id = converter_json(getattr(repo_card_data, "paperswithcode_id", None))
            task_ids = converter_json(getattr(repo_card_data, "task_ids", None))
            task_categories = converter_json(getattr(repo_card_data, "task_categories", None))
            train_eval_index = converter_json(getattr(repo_card_data, "train_eval_index", None))
            prettty_name = converter_json(getattr(repo_card_data, "pretty_name", None))
            downloads_all_time = converter_json(getattr(dataset, "downloads_all_time", None))
            
            if en_commit:
                cursor.execute(aux_hf.give_SQL_pattern("dataset_card"), ("datasets/" + repo_name, language, licence, annotations_creators, language_creators, source_datasets, paperswithcode_id, prettty_name, task_categories, task_ids, train_eval_index, downloads_all_time))

        else:
            downloads_all_time = converter_json(getattr(dataset, "downloads_all_time", None))
            if en_commit:
                cursor.execute(aux_hf.give_SQL_pattern("dataset_card"), ("datasets/" + repo_name, None, None, None, None, None, None, None, None, None, None, downloads_all_time))
                
        if en_commit:
            conn.commit()
            
        return ("datasets/" + repo_name, language, licence, annotations_creators, language_creators, source_datasets, paperswithcode_id, prettty_name, task_categories, task_ids, train_eval_index, downloads_all_time)
     
    except Exception as e:
        aux_hf.eprint("\n") 
        aux_hf.eprint("Error (dataset): " + repo_name + "): \n", sys.exc_info())
            

def populate_card_data(conn, cursor, repo_type, lst_object, token, filter = None, en_commit = True):
    found_filter = False
    conn.autocommit = en_commit
    
    #variables useful when auto commit is false, and we are committing every GLOBAL_BATCH_SIZE objects
    repo_queries, object_queries, updated_objects = [], [], 0
    query_type = ""
    count_skipped = 0

    
    if not en_commit:
        print("Autocommit disabled, changes will be committed every {} objects.".format(GLOBAL_BATCH_SIZE))
    # started 30 oct 2025 15:47 (-2 docker)4223
    for obj in lst_object:
        object_id = obj.get("id")
        
        print(f"Processing {repo_type}/{object_id}, updated_objects: {updated_objects}, en_commit: {en_commit}")
        
        count_skipped += 1
        if filter and not found_filter:
            if filter == object_id:
                found_filter = True
                print(f"Found filter {filter}, processing..., skipped {count_skipped}")
                print(object_id)
                continue
            else:
                continue
        
        if object_id in ["admin08077/Notmyopinion", "CyberHarem/lila_decyrus_azurlane", "Muhammad89/AOT"]: # datasets/
            print("FOUND", object_id, "skipping due to known issues.")  # 
            continue
            
        url_cardData =  define_url_readme(repo_type, object_id)
        card_data = None
        repo_card = None
        
        try:
            card_data, _ = fetch_data(url_cardData, aux_hf.define_session(), token=token)
        except EntryNotFoundError as entry_err:
            aux_hf.eprint(f"HTTP error occurred when fetching card data for {object_id}: {entry_err}")
            continue
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code if e.response is not None else None
            if status == 429 and aux_hf.is_cloudfront_error(e):
                aux_hf.eprint(f"429 for {object_id} (cloudfront={aux_hf.is_cloudfront_error(e)}), skipping for now")
                continue           
            elif status == 429:
                aux_hf.eprint(f"HTTP error{status} when fetching card data for {object_id}: {e}")
                raise
            continue
        except Exception as err:
            aux_hf.eprint(f"Other error occurred when fetching card data for {object_id}: {err}")
            continue
        
        
        try:
            repo_card = RepoCard(card_data)
        except Exception as err:
            try:
                repo_card = RepoCard(card_data, ignore_metadata_errors=True)
            except Exception as err:
                aux_hf.eprint(f"Error parsing README for {object_id}: {err}")
                continue

      
        if repo_card:
            repo_card_content = getattr(repo_card, "content", None)
            repo_card_text = getattr(repo_card, "text", None)
            repo_card_data = getattr(repo_card, "data", None)   
            str_repo_card_data = ""
            
            if repo_card_data:
                str_repo_card_data = str(vars(repo_card_data))
            else:
                str_repo_card_data = None
                
            repo_id = repo_type  + '/' + object_id   
            repo_card_content = aux_hf.sanitize_field(repo_card_content, repo_id=repo_id, field_name="card content")
            repo_card_text = aux_hf.sanitize_field(repo_card_text, repo_id=repo_id, field_name="card text")
            str_repo_card_data = aux_hf.sanitize_field(str_repo_card_data, repo_id=repo_id, field_name="str repo card content")
            # if repo_card_content:
            #     print(len(repo_card_content))
            # if repo_card_text:
            #     print(len(repo_card_text))
            # if str_repo_card_data:
            #     print(len(str_repo_card_data))
            # repo general card info
            if en_commit:
                #print(f"{repo_id}: content={len(repo_card_content or '')} " f"text={len(repo_card_text or '')} data={len(str_repo_card_data or '')}")
                cursor.execute(aux_hf.give_SQL_pattern("repo_card"), (repo_id, repo_card_content, repo_card_text, str_repo_card_data))
                conn.commit() # Commit changes to DB to fulfill FK restriction
            else:
                repo_queries.append((repo_id, repo_card_content, repo_card_text, str_repo_card_data) )
            
            # per object type 
            if "model" in repo_type:
                repo_name, base_model, eval_results, language, licence, licence_name, licence_link, datasets, metrics, pipeline_tag, model_name, downloads_all_time, tags, model_index = populate_model_card(cursor, conn, object_id, repo_card_data, obj, en_commit=en_commit)
                
                if not en_commit:
                    object_queries.append((repo_name, base_model, eval_results, language, licence, licence_name, licence_link, datasets, metrics, pipeline_tag, model_name, downloads_all_time, tags, model_index))
                    query_type = "model_card"
                                    
            elif "space" in repo_type:              
                repo_name, title, licence, duplicated_from, models, tags, datasets, downloads_all_time = populate_space_card(cursor, conn, object_id, repo_card_data, obj, en_commit=en_commit)
                
                if not en_commit:
                    object_queries.append((repo_name, title, licence, duplicated_from, models, tags, datasets, downloads_all_time))
                    query_type = "space_card"
                
            elif "dataset" in repo_type:
                #populate_dataset_card(cursor, conn, repo_name, repo_card_data, object_msd)
                repo_name, language, licence, annotations_creators, language_creators, source_datasets, paperswithcode_id, prettty_name, task_categories, task_ids, train_eval_index, downloads_all_time = populate_dataset_card(cursor, conn, object_id, repo_card_data, obj, en_commit=en_commit)
                
                if not en_commit:
                    object_queries.append((repo_name, language, licence, annotations_creators, language_creators, source_datasets, paperswithcode_id, prettty_name, task_categories, task_ids, train_eval_index, downloads_all_time))
                    query_type = "dataset_card"
                
        
        
        updated_objects += 1
        if updated_objects % GLOBAL_BATCH_SIZE == 0 and not en_commit:
            #conn.start_transaction()
            insert_many(conn, aux_hf.give_SQL_pattern("repo_card"), repo_queries)
            insert_many(conn, aux_hf.give_SQL_pattern(query_type), object_queries)
            conn.commit()  # Commit changes to DB every GLOBAL_BATCH_SIZE objects
            
            #clear lists and reset counter
            updated_objects = 0
            object_queries.clear()
            repo_queries.clear()
            print(f"Committed up to the object {object_id} card data so far...")
        #break
    if en_commit == False and updated_objects > 0:
        conn.ping(reconnect=True, attempts=3, delay=2)
        #conn.start_transaction()
        insert_many(conn, aux_hf.give_SQL_pattern("repo_card"), repo_queries)
        insert_many(conn, aux_hf.give_SQL_pattern(query_type), object_queries)
        conn.commit()
    if en_commit:
        conn.commit()  # Final commit for any remaining objects
    
def main(argv=None):
    print("Starting update card data info...")
    args = parse_args(argv or sys.argv[1:])
    
    host, port, user, password, db_name, token = "", 3306, "", "", "", "NA"
    host, port, user, password, db_name, token = aux_hf.read_env_variables()

    if token == "NA":
        aux_hf.eprint("Missing token in env variables. Please add token in 'hfh_token' field.")
        sys.exit(1)
        
    if user == "" or password == "" or db_name == "":
        aux_hf.eprint("Missing database configuration in env variables. Please add DB_USER, DB_PASS and DB_NAME.")
        sys.exit(1)
    
    conn, database = aux_hf.create_connection_mysql(host, port, user, password, db_name)
    c = conn.cursor()
    
    aux_hf.set_up_db(c, database)
    tables = aux_hf.check_database_schema(c, database)
    
    try:
        if len(tables)!= 0:
            aux_hf.eprint("Some tables are missing in the database. Please, run first 'main.py' to create the database schema.")
            sys.exit(1)
        
        en_commit = True
        if args.scope == "all":
            print("Loading all basic info...")
        elif args.scope == "datasets": # TRUE
            print("Reading datasets from pickle")
            datasets_loaded_pkl = aux_hf.load_pickle("/results/datasets_r2_10_09.pkl.gz")
            print("Populating datasets cards")
            populate_card_data(conn, c, "datasets", datasets_loaded_pkl, token, filter=None, en_commit=True) 
        elif args.scope == "models":      # FALSE  100    
            print("Reading models from pickle")
            models_loaded_pkl = aux_hf.load_pickle("/results/models_r2_10_09.pkl.gz")
            print("Populating model cards")
            populate_card_data(conn, c, "models", models_loaded_pkl, token, filter= None, en_commit=True) 
            
            # FROM THIS THE TRUUNCATED WAS IMPLEMENTED
        elif args.scope == "spaces":            
            print("Reading spaces from pickle")
            spaces_loaded_pkl = aux_hf.load_pickle("/results/spaces_r2_10_09.pkl.gz")
            print("Populating spaces cards")
            populate_card_data(conn, c, "spaces", spaces_loaded_pkl, token, filter= None, en_commit=True) 
            
    except Exception as e:
        conn.rollback()
        aux_hf.eprint("Error during the card data info update process:\n", sys.exc_info())
        raise e
        #sys.exit(1)
    finally:
        conn.commit()
        c.close()
        conn.close()
    
    print("Card data info update finished.")
    sys.exit(0)


if __name__ == "__main__":
    raise SystemExit(main())


