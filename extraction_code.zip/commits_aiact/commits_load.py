import stat
import os
import gc
import sys
import argparse


#import own dependencies
import aux_hf

from typing import Tuple, Dict
import requests
from tenacity import retry, stop_after_attempt, retry_if_exception


from datetime import datetime
import time

from huggingface_hub.utils import (
    HfHubHTTPError,
    RepositoryNotFoundError
    )

GLOBAL_BATCH_SIZE = 100
WINDOW_SEC = 5 * 60 # 5 minutes

def parse_args(argv):
    parser = argparse.ArgumentParser(description="Manage database schema and basic info.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-s", "--scope", choices=["datasets", "models", "spaces"],
                       default="models",help="Load basic information to some.")
    
    return parser.parse_args(argv)

def insert_many(conn, sql, rows):
    with conn.cursor() as cur:
        cur.executemany(sql, rows) 

def define_url_references(repo_type, object_id):
    url_prefix = f"{repo_type}/"
    url = f"https://huggingface.co/api/{url_prefix}{object_id}/refs"# it is the default branch used by 
    return url 
    

def define_url_commit(repo_type, object_id, next_page=None, branch = "main"):
    if next_page:
        params = {}
        return next_page, params
    else:
        url_prefix = f"{repo_type}/"
        url = f"https://huggingface.co/api/{url_prefix}{object_id}/commits/{branch}"# it is the default branch used by hugging face
        params = {"limit": 100}
        return url, params


@retry(
    retry=retry_if_exception(aux_hf.is_retryable_http_error),
    wait=aux_hf.wait_for_reset,                
    stop=stop_after_attempt(10),
    reraise=True,
)
def fetch_branches(url: str, session: requests.Session, timeout: float= 30, params: dict={}, token: str="") -> Dict:    
    headers = {"Authorization": f"Bearer {token}"} if token != "" else {}
    resp = session.get(url, params=params, timeout=timeout, headers=headers)
    resp.raise_for_status()
    response = resp.json()
    
    branches = response.get("branches", [])
    result = []
    for branch in branches:        
        if branch.get("name", None):
            result.append(branch.get("name"))
            
    branches = list(set(result))  if len(result)>=1 else ["main"] # Remove duplicates if any
    # To do CORREGIR SOLO DEBE SER > 1 no >=
    
    return branches
    
@retry(
    retry=retry_if_exception(aux_hf.is_retryable_http_error),
    wait=aux_hf.wait_for_reset,                
    stop=stop_after_attempt(10),
    reraise=True,
)
def fetch_commits(url: str, session: requests.Session, timeout: float= 30, params: dict={}, token: str="") -> Tuple[Dict, bool]: 
    headers = {"Authorization": f"Bearer {token}"} if token != "" else {}
    
    resp = session.get(url, params=params, timeout=timeout, headers=headers)
    
    resp.raise_for_status()
    has_next = False
    next_page = resp.links.get("next", {}).get("url")
    
    if next_page:
        # print(f"Next page found: {next_page} d")
        has_next = True
        
    commits = resp.json()
    
    return commits, has_next, next_page
   

def insert_author_commits(object, cursor, conn, lst_authors_commits, en_commit = True):
    """
    Insert author into the database if not already present.
    """
    authorhip = []
    author_name = None
    avatar_url = None
    source = None
    
    if object:
        authors = object.get("authors", [])
        
        for i, auth in enumerate(authors):
            author_name = auth.get("user", "deleted")
            avatar_url = auth.get("avatar", None)
            source = "committer_hf_commit" if i == 0 else "author_hf_commit"
            lst_authors_commits.append( (author_name, avatar_url, source) )
            authorhip.append( (author_name, avatar_url, source) )
            
    
        if en_commit and len(authorhip) > 0:
            for author in authorhip:
                cursor.execute(aux_hf.give_SQL_pattern("author_commit"), (author[0], author[1], author[2]))
            conn.commit()

    return authorhip


def insert_commits(object, committer, author, cursor, conn, repo_name, repo_type, lst_commits, en_commit = True, branch = "main"):
    """
    Insert commit into the database if not already present.
    """
    sha = None
    repo_id = repo_type + "/" + repo_name
    committer_date = None
    committer_tz = None
    message = None
    in_main_branch =  1 if branch == "main" else 0
    source = None
    committer = committer
    author = author
    source = "pydriller"
    title = None
    
    if object:
        sha = object.get("id", None)
        committer_date = object.get("date", None)
        committer_tz = aux_hf.extract_tz(committer_date).get("offset_seconds", None)
        committer_date = aux_hf.convert_to_utc(committer_date)
        message = object.get("message", None)
        title = object.get("title", None)
        
    if en_commit and object:
        cursor.execute(aux_hf.give_SQL_pattern("commit"), (sha, repo_id, committer_date, committer_tz, message, in_main_branch, author, committer, source, title))
        conn.commit()
    elif not en_commit and object:
        lst_commits.append((sha, repo_id, committer_date, committer_tz, message, in_main_branch, author, committer, source, title))
    
    return (sha, repo_id, committer_date, committer_tz, message, in_main_branch, author, committer, source, title)


    
def load_commits(cursor, conn, object_id, repo_type, token, en_commit=True, branch="main"):
    """ 
    Importation of commit information using PyDriller.
    It inserts commit information into ``commits``, ``author``, ``modified_file`` and ``files_in_commit`` tables.
    
    :param cursor: The MySQL connection cursor to execute operations such as SQL statements.
    :type cursor: `cursor.MySQLCursor`_
    :param conn: The MySQL connector to the database specified in the env variables. Used to commit changes to fulfill FK restrictions. Used to commit changes to fulfill FK restrictions.
    :type conn: `connection.MySQLConnection`_
    :param repo_name: The full name (i.e., "owner/repo_name") of the repository.
    :type repo_name: str
    :param repo_type: The type of the repository (i.e., model, dataset or space)
    :type repo_type: str
    """

    has_next, page, response_link  = True, 0, None
    lst_authors_commits, lst_commits = [], []
    commits = None
    next_page = None
    
    while has_next:
        
        if page > 0:
            next_page = response_link
        
        url, params = define_url_commit(repo_type, object_id, next_page, branch) 

        
        try:
            commits, has_next, response_link  = fetch_commits(url, aux_hf.define_session(), params=params, token=token)
            # EXCEPTION 
        except requests.exceptions.HTTPError as e:
            aux_hf.eprint(f"COMMIT Error fetching for {repo_type} {object_id} commits {page}: {str(e)}") 
            if e.response is not None and e.response.status_code == 429:
                raise e
            return (lst_authors_commits, lst_commits) 
        
        
        for commit in commits:
            author_info= insert_author_commits(commit, cursor, conn, lst_authors_commits, en_commit)
            
            author_name = None
            committer_name = None
            
            if len(author_info) > 0:
                if len(author_info) == 1 or len(author_info) == 2:
                    committer_name = author_info[0][0]
                if len(author_info) == 2:
                    author_name = author_info[1][0]            
            
            insert_commits(commit, committer_name, author_name, cursor, conn, object_id, repo_type, lst_commits, en_commit)
            
        page += 1
    
    return lst_authors_commits, lst_commits
            

def populate_commits(conn, cursor, repo_type, lst_object, token, filter = None, en_commit = True):

    found_filter = False
    conn.autocommit = en_commit
    
    #variables useful when auto commit is false, and we are committing every GLOBAL_BATCH_SIZE objects
    lst_authors_commits, lst_commits = [], []
    updated_objects = 0
    
    # just monitoring time
    window_start = time.monotonic()
    next_tick = window_start + WINDOW_SEC
    done_in_window = 0
    branches = None # default branch used by hugging face
    skipped = []
    
    for obj in lst_object:
        object_id = obj.get("id")
        
        print(f"Processing commits {repo_type}/{object_id}, updated_objects: {updated_objects}, en_commit: {en_commit}")
        
        if filter and not found_filter:
            if filter == object_id:
                found_filter = True
                print(f"Found filter {filter}, processing...")
                print(object_id)
                continue
            else:
                continue
        if object_id in ["Upabjojr/elevation-data-ASTER-compressed-retiled"]:# Upa do o time request
            print("FOUND", object_id, "skipping due to known issues.")
            continue
        
        url_branches = define_url_references(repo_type, object_id)
        try:        
            branches = fetch_branches(url_branches, aux_hf.define_session(), token=token)
            
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code if e.response is not None else None
            if status == 404:
                aux_hf.eprint(f"Repositorio {object_id} no encontrado (404), se omite.")
                skipped.append((object_id, 404))
                continue
            if status in (401, 403):
                aux_hf.eprint(f"Sin acceso a {object_id} (HTTP {status}), probablemente gated. Se omite.")
                skipped.append((object_id, status))
                continue
            if status == 400:
                aux_hf.eprint(f"url badly formmed due to problems in API {object_id} (HTTP {status})")
                skipped.append((object_id, status))
                continue
            raise
        except (requests.ConnectionError, requests.Timeout) as e:
            aux_hf.eprint(f"Error de red en {object_id}: {e}")
            skipped.append((object_id, "network"))
            continue
        
        for branch in branches:
            try:        
                lst_auth, lst_comts  = load_commits(cursor, conn, object_id, repo_type, token, en_commit=en_commit, branch=branch)
            except HfHubHTTPError as e:
                aux_hf.eprint(f"for {object_id} HuggingFace API returned an error.HRRP not FOUND ERROR: {str(e)}")
                if e.response is not None and e.response.status_code == 429:
                    raise e
                continue
            except RepositoryNotFoundError as ex:
                aux_hf.eprint(f"The repository {object_id} to download from cannot be found. This may be because it does not exist, or because it is set to private and you do not have access. REPO not FOUND ERROR: {str(e)}")
                continue
            
            if not en_commit:
                if len(lst_auth) > 0:
                    lst_authors_commits.extend(lst_auth)
                if len(lst_comts) > 0:
                    lst_commits.extend(lst_comts)
        updated_objects += 1
        done_in_window += 1
        
        now = time.monotonic()
        if now >= next_tick:
            print(f"Inserted commits for {repo_type} {done_in_window}")
            done_in_window = 0
            next_tick += WINDOW_SEC
            
        if updated_objects % GLOBAL_BATCH_SIZE == 0 and not en_commit:
            #conn.start_transaction()
            insert_many(conn, aux_hf.give_SQL_pattern("author_commit"), lst_authors_commits) #1
            insert_many(conn, aux_hf.give_SQL_pattern("commit"), lst_commits) #2
            conn.commit()
            
            #clear lists and reset counter
            updated_objects = 0
            lst_authors_commits.clear()
            lst_commits.clear()
            print(f"Committed up to the object {repo_type}/{object_id} in the batch.")
            print("skipped", skipped)
            skipped.clear()
    
    if en_commit == False and updated_objects > 0:
        #conn.start_transaction()
        insert_many(conn, aux_hf.give_SQL_pattern("author_commit"), lst_authors_commits) #1
        insert_many(conn, aux_hf.give_SQL_pattern("commit"), lst_commits) #2
        conn.commit()
        
        #clear lists and reset counter
        updated_objects = 0
        lst_authors_commits.clear()
        lst_commits.clear()
        print("skipped", skipped)
        print(f"Committed up to the object {repo_type}/{object_id} in the batch.")
    else:
        conn.commit()

def main(argv=None):
    print("Starting update commits info...")
    args = parse_args(argv or sys.argv[1:])
    
    host, port, user, password, db_name, token = "", 3306, "", "", "", "NA"
    host, port, user, password, db_name, token = aux_hf.read_env_variables()
    
    if token == "NA":
        aux_hf.eprint("Missing token in env variables. Please add token in 'hfh_token' field.")
        sys.exit(1)
        
    if user == "" or password == "" or db_name == "":
        aux_hf.eprint("Missing database configuration in env variables. Please add DB_USER, DB_PASS and DB_NAME.")
        sys.exit(1)
    
    conn, database = aux_hf.create_connection_mysql(host, port, user, password, db_name)
    c = conn.cursor()
    
    aux_hf.set_up_db(c, database)
    tables = aux_hf.check_database_schema(c, database)

   
    try:
        if len(tables)!= 0:
            aux_hf.eprint("Some tables are missing in the database. Please, run first 'main.py' to create the database schema.")
            sys.exit(1)
        
        en_commit = False # manually defined this
        if args.scope == "datasets":
            print("Reading datasets from pickle")
            datasets_loaded_pkl = aux_hf.load_pickle("/results/datasets_r2_10_09.pkl.gz")
            print("Populating commits for datasets")
            populate_commits(conn, c, "datasets", datasets_loaded_pkl, token, filter = None, en_commit = en_commit)
        elif args.scope == "models":
            print("Reading models from pickle")
            models_loaded_pkl = aux_hf.load_pickle("/results/models_r2_10_09.pkl.gz")
            print("Populating commits for models")
            populate_commits(conn, c, "models", models_loaded_pkl, token, filter = None, en_commit = en_commit)
        elif args.scope == "spaces":
            print("Reading spaces from pickle")
            spaces_loaded_pkl = aux_hf.load_pickle("/results/spaces_r2_10_09.pkl.gz")           
            print("Populating commits for spaces")
            populate_commits(conn, c, "spaces", spaces_loaded_pkl, token, filter = None, en_commit = en_commit)
    
    except Exception as e:
        conn.rollback()
        aux_hf.eprint("Error during the commits info update process:\n", sys.exc_info())
        raise e
        #sys.exit(1)
    finally:
        conn.commit()
        c.close()
        conn.close()
    
    print("Commits info update finished.")
    sys.exit(0)
# docker-compose stop appcsp
# docker-compose rm -fsv appcsp
# docker-compose build --no-cache appcsp
# docker-compose up -d appcsp
# docker-compose logs -t appcsp

if __name__ == "__main__":
    raise SystemExit(main())